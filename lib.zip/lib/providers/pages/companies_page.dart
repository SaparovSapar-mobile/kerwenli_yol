import 'package:flutter_riverpod/flutter_riverpod.dart';

final StateProvider<int> companySortIndexProvider = StateProvider<int>(
  (ref) => 0,
);
final StateProvider<int> companyMessageListtileIndexProvider =
    StateProvider<int>((ref) => 0);

final AutoDisposeStateProvider<bool> hasBCompaniesProvider =
    StateProvider.autoDispose<bool>((ref) => true);
final StateProvider<bool> hasErrBCompaniesProvider = StateProvider<bool>(
  (ref) => false,
);
final StateProvider<bool> loadBCompaniesProvider = StateProvider<bool>(
  (ref) => true,
);

final AutoDisposeStateProvider<bool> hasFCompaniesProvider =
    StateProvider.autoDispose<bool>((ref) => true);
final StateProvider<bool> hasErrFCompaniesProvider = StateProvider<bool>(
  (ref) => false,
);
final StateProvider<bool> loadFCompaniesProvider = StateProvider<bool>(
  (ref) => true,
);

final AutoDisposeStateProvider<bool> hasCompaniesProvider =
    StateProvider.autoDispose<bool>((ref) => true);
final StateProvider<bool> hasErrCompaniesProvider = StateProvider<bool>(
  (ref) => false,
);
final StateProvider<bool> loadCompaniesProvider = StateProvider<bool>(
  (ref) => true,
);

final AutoDisposeStateProvider<bool> sendMsgBtnPressProvider =
    StateProvider.autoDispose<bool>((ref) => false);
