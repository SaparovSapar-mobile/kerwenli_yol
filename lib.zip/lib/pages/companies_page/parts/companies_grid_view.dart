import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerwenli_yol/helpers/methods/static_data.dart';
import 'package:kerwenli_yol/helpers/methods/static_methods.dart';
import 'package:kerwenli_yol/models/company.dart';
import 'package:kerwenli_yol/pages/companies_page/parts/company_card/company_card.dart';
import 'package:kerwenli_yol/pages/parts/no_result.dart';
import 'package:kerwenli_yol/pages/parts/some_error.dart';
import 'package:kerwenli_yol/providers/api/company.dart';
import 'package:kerwenli_yol/providers/pages/companies_page.dart';
import 'package:kerwenli_yol/services/api/company.dart';

class CompaniesGridView extends ConsumerWidget {
  const CompaniesGridView({super.key, required this.categoryId});

  final String categoryId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final CompanyParams firstArg = CompanyParams(
      page: 1,
      pageSize: pageSize,
      categoryId: categoryId,
      userId: '',
    );

    final AsyncValue<List<CompanyDetailModel>> firstPage = ref.watch(
      fetchCompaniesByCategoryIdProvider(firstArg),
    );

    return firstPage.when(
      loading: () => loadWidget,
      error: (error, stackTrace) => SomeError(
        ref: ref,
        apiProviders: [fetchCompaniesByCategoryIdProvider],
      ),
      data: (firstData) {
        if (firstData.isEmpty) return NoResult();

        final bool hasErr = ref.watch(hasErrCompaniesProvider);
        if (hasErr) {
          return SomeError(
            ref: ref,
            apiProviders: [fetchCompaniesByCategoryIdProvider],
          );
        }

        final int totalItems = firstData.length;

        return GridView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            mainAxisExtent: companyCardHeight,
          ),
          itemCount: totalItems,
          itemBuilder: (context, index) {
            final int page = index ~/ pageSize + 1;
            final int indexInPage = index % pageSize;

            final CompanyParams arg = CompanyParams(
              page: page,
              pageSize: pageSize,
              categoryId: categoryId,
              userId: '',
            );

            final AsyncValue<List<CompanyDetailModel>> resultApi = ref.watch(
              fetchCompaniesByCategoryIdProvider(arg),
            );

            return resultApi.when(
              data: (response) {
                if (indexInPage >= response.length) return null;

                final CompanyDetailModel c = response[indexInPage];
                final CompanyModel company = CompanyModel(
                  viewsCount: 0,
                  uuid: '',
                  individualUuid: c.id,
                  photo: c.mainInfo.logoImg,
                  nameTm: c.businessName.tm,
                  nameRu: c.businessName.ru,
                  nameEn: c.businessName.en,
                  isBookmarked: c.isBookmarked,
                  isFollowed: c.isFollowed,
                  categoryName: c.categoryName,
                  publicationLabelTm: '',
                  publicationLabelRu: '',
                  publicationLabelEn: '',
                );
                return CompanyCard(company: company);
              },
              error: (error, stackTrace) => SomeError(
                ref: ref,
                apiProviders: [fetchCompaniesByCategoryIdProvider],
              ),
              loading: () => loadWidget,
            );
          },
        );
      },
    );
  }
}