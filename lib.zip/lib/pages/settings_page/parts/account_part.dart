import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerwenli_yol/helpers/functions/theme.dart';
import 'package:kerwenli_yol/helpers/methods/pages/bottom_sheets.dart';
import 'package:kerwenli_yol/l10n/app_localizations.dart';
import 'package:kerwenli_yol/models/user.dart';
import 'package:kerwenli_yol/pages/settings_page/parts/setting_part_card.dart';
import 'package:kerwenli_yol/providers/database/user.dart';
import 'package:kerwenli_yol/styles/colors/dark_colors.dart';
import 'package:kerwenli_yol/styles/colors/light_colors.dart';

class AccountPart extends ConsumerWidget {
  const AccountPart({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations lang = AppLocalizations.of(context)!;

    final bool isLight = isLightTheme(context, ref);
    final Color bgColor = isLight
        ? LightColors.bgBlogLight
        : DarkColors.bgBlogDark;

    final AsyncValue<UserModel> resultDB = ref.watch(getUserProvider);

    return resultDB.when(
      data: (data) {
        final bool noUser = data.id == '' || data.token == '';
        if (noUser) {
          return const SizedBox.shrink();
        }

        return Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Akkount'),
              SizedBox(height: 5),
              SettingPartCard(
                index: 8,
                text: lang.signOut,
                icon: Icons.logout,
                onTap: () => showLougOutBottomSheet(context),
              ),
              SettingPartCard(
                index: 9,
                text: lang.deleteAccount,
                icon: Icons.delete_forever,
                onTap: () => showDeleteAccountBottomSheet(context),
              ),
            ],
          ),
        );
      },
      error: (_, _) => const SizedBox.shrink(),
      loading: () => const SizedBox.shrink(),
    );
  }
}
