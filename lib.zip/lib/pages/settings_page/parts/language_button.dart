import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerwenli_yol/helpers/methods/pages/bottom_sheets.dart';
import 'package:kerwenli_yol/l10n/app_localizations.dart';
import 'package:kerwenli_yol/pages/settings_page/parts/setting_part_card.dart';
import 'package:kerwenli_yol/providers/settings.dart';

class LanguageButton extends ConsumerWidget {
  const LanguageButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations langg = AppLocalizations.of(context)!;

    String langText = '';
    final String lang = ref.watch(langProvider);

    if (lang == 'tk') {
      langText = 'Türkmençe';
    } else if (lang == 'tr') {
      langText = 'Türkçe';
    } else if (lang == 'ru') {
      langText = 'Русский';
    } else {
      langText = 'English';
    }

    return SettingPartCard(
      index: 0,
      text: langg.language,
      icon: Icons.translate,
      tralingText: langText,
      onTap: () => showLanguageBottomSheet(context),
    );
  }
}
