import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerwenli_yol/helpers/functions/navigation.dart';
import 'package:kerwenli_yol/helpers/functions/theme.dart';
import 'package:kerwenli_yol/helpers/functions/translations.dart';
import 'package:kerwenli_yol/helpers/methods/image_and_video.dart';
import 'package:kerwenli_yol/models/category.dart';
import 'package:kerwenli_yol/pages/companies_page/companies_page.dart';
import 'package:kerwenli_yol/styles/colors/dark_colors.dart';
import 'package:kerwenli_yol/styles/colors/light_colors.dart';
import 'package:kerwenli_yol/styles/text_styles.dart';

class HomeCategoryCard extends ConsumerWidget {
  const HomeCategoryCard({
    super.key,
    this.isFirst,
    this.isLast,
    required this.category,
  });

  final bool? isFirst, isLast;
  final CategoryModel category;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // =========== Colors ===============
    final bool isLight = isLightTheme(context, ref);
    final Color bgColor = isLight
        ? LightColors.bgPageLight
        : DarkColors.bgPageDark;
    final Color inBgColor = isLight
        ? LightColors.bgBlogLight
        : DarkColors.bgBlogDark;

    // =========== Text Styles ===============
    final TextStyle textStyle = AppTextStyles.medium12;

    final String name = translateText(
      ref,
      category.nameTm,
      category.nameRu,
      category.nameEn,
      category.nameEn,
    );

    final String image = translateText(
      ref,
      category.imageTm,
      category.imageRu,
      category.imageEn,
      category.imageEn,
    );

    // 9f4806b2-2fc8-4de1-8c32-63b5f24f57b2

    return GestureDetector(
      onTap: () => goToPage(
        context,
        CompaniesPage(categoryId: category.id),
        AxisDirection.left,
      ),
      child: Container(
        width: 160,
        padding: EdgeInsets.symmetric(horizontal: 5, vertical: 9),
        margin: isFirst != null && isLast != null
            ? EdgeInsets.only(left: isFirst! ? 16 : 0, right: isLast! ? 16 : 0)
            : null,
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Row(
          children: [
            Container(
              height: 35,
              width: 35,
              padding: EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: inBgColor,
                borderRadius: BorderRadius.circular(5),
              ),
              child: showImageMethod(image, 5, null),
            ),
            SizedBox(width: 5),
            Expanded(
              child: Text(
                name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: textStyle,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
