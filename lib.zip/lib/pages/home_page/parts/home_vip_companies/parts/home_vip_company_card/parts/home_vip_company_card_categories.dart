import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerwenli_yol/helpers/functions/theme.dart';
import 'package:kerwenli_yol/styles/colors/dark_colors.dart';
import 'package:kerwenli_yol/styles/colors/light_colors.dart';
import 'package:kerwenli_yol/styles/text_styles.dart';

class HomeVipCompanyCardCategories extends ConsumerWidget {
  const HomeVipCompanyCardCategories({
    super.key,
    this.iconSize,
    this.mainAxisAlignment,
    this.category,
  });

  final double? iconSize;
  final MainAxisAlignment? mainAxisAlignment;
  final String? category;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ======== Colors =======
    final bool isLight = isLightTheme(context, ref);
    final Color bgColor = isLight
        ? LightColors.bgPageLight
        : DarkColors.bgPageDark;

    // ======== Text Styles ======
    final TextStyle textStyle = AppTextStyles.medium10.copyWith(
      fontSize: iconSize ?? 8,
    );

    final bool hasAligment = mainAxisAlignment != null;

    return GestureDetector(
      onTap: () {},
      child: Align(
        alignment: Alignment.centerLeft, // sola yasla
        child: Container(
          padding: EdgeInsets.all(2),
          decoration: BoxDecoration(color: bgColor),
          child: Row(
            mainAxisSize: hasAligment ? MainAxisSize.min : MainAxisSize.max,
            mainAxisAlignment:
                mainAxisAlignment ?? MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Text(
                  category ?? 'Category/sub category',
                  style: textStyle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              hasAligment ? SizedBox(width: 5) : const SizedBox.shrink(),
              Icon(Icons.arrow_forward_ios, size: iconSize ?? 6),
            ],
          ),
        ),
      ),
    );
  }
}
