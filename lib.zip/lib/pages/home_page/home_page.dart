import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerwenli_yol/helpers/methods/parts/app_bar_methods.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_banners/home_banners.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_categories/home_categories.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_graditutes/home_graditutes.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_leader_companies/home_leader_companies.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_marks/home_marks.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_media/home_media.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_new_products/home_new_products.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_news/home_news.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_page_top/home_page_top.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_partners/home_partners.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_second_banner.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_vip_companies/home_vip_companies.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_virtuals/home_virtuals.dart';
import 'package:kerwenli_yol/providers/api/banner.dart';
import 'package:kerwenli_yol/providers/api/category.dart';
import 'package:kerwenli_yol/providers/api/company.dart';
import 'package:kerwenli_yol/providers/api/gratitude.dart';
import 'package:kerwenli_yol/providers/api/mark.dart';
import 'package:kerwenli_yol/providers/api/mark_type.dart';
import 'package:kerwenli_yol/providers/api/media.dart';
import 'package:kerwenli_yol/providers/api/news.dart';
import 'package:kerwenli_yol/providers/api/product.dart';
import 'package:kerwenli_yol/providers/api/sponsor.dart';
import 'package:kerwenli_yol/providers/parts/scroll_to_top.dart';
import 'package:kerwenli_yol/styles/colors/light_colors.dart';

import '../../models/default_params.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ScrollController scrollCtrl = ref.watch(mainPageScrollCtrlProvider);

    return RefreshIndicator(
      onRefresh: () async {
        ref.invalidate(fetchBannersProvider);
        ref.invalidate(fetchCategoriesProvider);
        ref.invalidate(fetchBestCompaniesProvider);
        ref.invalidate(fetchVipCompaniesProvider);
        ref.invalidate(fetchNewProductsProvider);
        ref.invalidate(fetchTravelsProvider);
        ref.invalidate(fetchMediasProvider);
        ref.invalidate(fetchNewsProvider);
        ref.invalidate(fetchMarkTypesProvider);
        ref.invalidate(fetchMarksProvider);
        ref.invalidate(fetchSponsorsProvider);
        ref.invalidate(fetchGradtitudesProvider);

        // Ждём пока все данные придут
        await Future.wait([
          ref.read(fetchBannersProvider.future),
          ref.read(fetchCategoriesProvider.future),
          ref.read(fetchBestCompaniesProvider.future),
          ref.read(fetchVipCompaniesProvider.future),
          ref.read(fetchNewProductsProvider.future),
          ref.read(fetchTravelsProvider.future),
          ref.read(fetchMediasProvider(DefaultParams()).future),
          ref.read(fetchNewsProvider(DefaultParams()).future),
          ref.read(fetchMarkTypesProvider.future),
          ref.read(fetchMarksProvider(DefaultParams() as String).future),
          ref.read(fetchSponsorsProvider(DefaultParams()).future),
          ref.read(fetchGradtitudesProvider(DefaultParams()).future),
        ]);
      },

      backgroundColor: Colors.white,
      color: LightColors.primary,
      child: Column(
        children: [
          HomePageTop(),
          AppBarBottomLine(thickness: 10),
          Expanded(
            child: ListView(
              controller: scrollCtrl,
              children: [
                HomeBanners(),
                AppBarBottomLine(thickness: 10),
                HomeCategories(),
                HomeLeaderCompanies(),
                HomeVipCompanies(),
                HomeNewProducts(),
                HomeVirtuals(),
                HomeMedia(),
                HomeNews(),
                HomeSecondBanner(),
                HomeMarks(),
                HomePartners(),
                HomeGraditutes(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
