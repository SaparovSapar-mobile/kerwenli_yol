import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:kerwenli_yol/helpers/methods/image_and_video.dart';
import 'package:kerwenli_yol/pages/home_page/parts/home_banners/parts/banner_dots.dart';

class CompanyBanner extends StatefulWidget {
  const CompanyBanner({
    super.key,
    required this.height,
    required this.width,
    required this.borderRadius,
    required this.dotsLeft,
    required this.dotsBottom,
    required this.dotsSize,
    required this.dotsActiveWidth,
    required this.dotsActiveHeight,
    required this.images,
  });

  final double height,
      width,
      borderRadius,
      dotsLeft,
      dotsBottom,
      dotsSize,
      dotsActiveWidth,
      dotsActiveHeight;

  final List<dynamic> images;

  @override
  State<CompanyBanner> createState() => _CompanyBannerState();
}

class _CompanyBannerState extends State<CompanyBanner> {
  final CarouselSliderController _controller = CarouselSliderController();

  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final int len = widget.images.length;
    final bool hasMore = len > 1;

    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(widget.borderRadius),
        clipBehavior: Clip.hardEdge,
        child: Stack(
          children: [
            CarouselSlider.builder(
              itemCount: len,
              itemBuilder: (context, index, realIndex) {
                return showImageMethod(widget.images[index], 0, null);
              },
              options: CarouselOptions(
                height: widget.height,
                viewportFraction: 1.0, // tam ekran gibi
                enableInfiniteScroll: hasMore,
                autoPlay: hasMore,
                autoPlayInterval: const Duration(seconds: 3),
                autoPlayAnimationDuration: const Duration(milliseconds: 800),
                autoPlayCurve: Curves.easeOut,
                pauseAutoPlayOnTouch: true, // kullanıcı dokununca durur
                pauseAutoPlayOnManualNavigate: true,
                pauseAutoPlayInFiniteScroll: true,
                onPageChanged: (index, reason) {
                  setState(() => _currentIndex = index);
                },
              ),
              carouselController: _controller,
            ),

            if (hasMore)
              Positioned(
                left: widget.dotsLeft,
                bottom: widget.dotsBottom,
                child: BannerDots(
                  lenght: len,
                  page: _currentIndex,
                  dotsSize: widget.dotsSize,
                  dotsActiveWidth: widget.dotsActiveWidth,
                  dotsActiveHeight: widget.dotsActiveHeight,
                ),
              )
            else
              const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }
}
